-- RGV Property360 :: 009 Authorization helper functions used by RLS policies and RPCs.
-- All are SECURITY DEFINER + fixed search_path so policies can consult RLS-protected tables without recursion.

create function app.org_id() returns uuid language sql stable security definer set search_path = '' as $$
  select p.organization_id from public.profiles p
  where p.id = auth.uid() and p.is_active and p.deleted_at is null
$$;

create function app.has_any_role(roles public.app_role[]) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.user_roles ur
    join public.profiles p on p.id = ur.user_id and p.is_active and p.deleted_at is null
    where ur.user_id = auth.uid() and ur.revoked_at is null and ur.role = any (roles))
$$;

create function app.has_role(r public.app_role) returns boolean language sql stable security definer set search_path = '' as $$
  select app.has_any_role(array[r]) $$;

-- Organization-wide administrators.
create function app.is_admin() returns boolean language sql stable security definer set search_path = '' as $$
  select app.has_any_role(array['super_admin','admin']::public.app_role[]) $$;

create function app.is_project_member(pid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.project_members pm
                 where pm.project_id = pid and pm.user_id = auth.uid() and pm.removed_at is null)
$$;

-- Admins: any project of their own organization. Others: only assigned projects (and they must hold some role).
create function app.can_access_project(pid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.projects pr
    where pr.id = pid and pr.organization_id = app.org_id()
      and (app.is_admin()
           or (app.is_project_member(pid) and app.has_any_role(
                 array['project_manager','sales_manager','salesperson','accounting','documents_officer','viewer']::public.app_role[]))))
$$;

-- Project access AND one of the given roles (admins always pass).
create function app.has_project_role(pid uuid, roles public.app_role[]) returns boolean language sql stable security definer set search_path = '' as $$
  select app.can_access_project(pid) and (app.is_admin() or app.has_any_role(roles)) $$;

-- Authorized approvers: project/sales managers assigned to the project, plus admins.
create function app.is_approver(pid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select app.has_project_role(pid, array['project_manager','sales_manager']::public.app_role[]) $$;

-- Transaction visibility: project staff roles see all project transactions; salespeople see only their own.
create function app.can_view_scope(pid uuid, agent uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select app.can_access_project(pid) and (
    app.is_admin()
    or app.has_any_role(array['project_manager','sales_manager','accounting','documents_officer']::public.app_role[])
    or agent = auth.uid()) $$;

create function app.can_view_sale(sid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce((select app.can_view_scope(s.project_id, s.agent_id) from public.sales s where s.id = sid), false) $$;

create function app.can_view_reservation(rid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce((select app.can_view_scope(r.project_id, r.agent_id) from public.reservations r where r.id = rid), false) $$;

-- Private buyer rule. Visible to: admin, owner, active grantee, the agent of one of the buyer's transactions,
-- and manager/accounting/documents roles on a project where the buyer has a reservation, sale or lead.
create function app.can_view_buyer(bid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.buyers b
    where b.id = bid and b.deleted_at is null and b.organization_id = app.org_id()
      and (
        app.is_admin()
        or b.owner_id = auth.uid()
        or exists (select 1 from public.buyer_access_grants g
                   where g.buyer_id = b.id and g.granted_to = auth.uid() and g.revoked_at is null
                     and (g.expires_at is null or g.expires_at > now()))
        or exists (select 1 from public.reservations r where r.buyer_id = b.id and
                   (r.agent_id = auth.uid() or app.has_project_role(r.project_id,
                      array['project_manager','sales_manager','accounting','documents_officer']::public.app_role[])))
        or exists (select 1 from public.sales s where s.buyer_id = b.id and
                   (s.agent_id = auth.uid() or app.has_project_role(s.project_id,
                      array['project_manager','sales_manager','accounting','documents_officer']::public.app_role[])))
        or exists (select 1 from public.leads l where l.buyer_id = b.id and l.project_id is not null and
                   app.has_project_role(l.project_id, array['project_manager','sales_manager']::public.app_role[]))
      ))
$$;

create function app.can_edit_buyer(bid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.buyers b
    where b.id = bid and b.deleted_at is null and b.organization_id = app.org_id()
      and (app.is_admin() or b.owner_id = auth.uid()
           or exists (select 1 from public.buyer_access_grants g
                      where g.buyer_id = b.id and g.granted_to = auth.uid() and g.revoked_at is null and g.can_edit
                        and (g.expires_at is null or g.expires_at > now()))))
$$;

create function app.can_view_lead(pid uuid, assignee uuid, creator uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select app.org_id() is not null and (
    app.is_admin() or assignee = auth.uid() or creator = auth.uid()
    or (pid is not null and app.has_project_role(pid, array['project_manager','sales_manager']::public.app_role[]))) $$;

create function app.can_view_lead_id(lid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce((select app.can_view_lead(l.project_id, l.assigned_to, l.created_by)
                   from public.leads l where l.id = lid and l.deleted_at is null and l.organization_id = app.org_id()), false) $$;

create function app.can_view_document(
  p_org uuid, p_project uuid, p_buyer uuid, p_lot uuid, p_res uuid, p_sale uuid, p_pay uuid,
  p_uploader uuid, p_conf boolean) returns boolean language plpgsql stable security definer set search_path = '' as $$
declare v_proj uuid; roles public.app_role[];
begin
  if p_org is distinct from app.org_id() then return false; end if;
  if p_uploader = auth.uid() or app.is_admin() then return true; end if;
  v_proj := coalesce(p_project,
    (select project_id from public.lots where id = p_lot),
    (select project_id from public.reservations where id = p_res),
    (select project_id from public.sales where id = p_sale),
    (select project_id from public.payments where id = p_pay));
  roles := case when p_conf then array['project_manager','sales_manager']::public.app_role[]
                else array['project_manager','sales_manager','accounting','documents_officer']::public.app_role[] end;
  if v_proj is not null and app.has_project_role(v_proj, roles) then return true; end if;
  if p_conf then return false; end if;
  if p_sale is not null and app.can_view_sale(p_sale) then return true; end if;
  if p_res  is not null and app.can_view_reservation(p_res) then return true; end if;
  if p_pay  is not null and app.can_view_sale((select sale_id from public.payments where id = p_pay)) then return true; end if;
  if p_buyer is not null and app.can_view_buyer(p_buyer) then return true; end if;
  return false;
end $$;

create trigger trg_profiles_guard before update on public.profiles for each row execute function app.guard_profiles();
