-- RGV Property360 :: 005 Buyers, addresses, access grants, leads, CRM activities
create table public.buyers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  owner_id uuid not null references public.profiles(id),          -- salesperson who "owns" this private record
  buyer_type public.buyer_type not null default 'individual',
  first_name text, middle_name text, last_name text, company_name text,
  email text check (email is null or email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  phone text, mobile text,
  birth_date date,
  civil_status text check (civil_status is null or civil_status in ('single','married','widowed','separated','divorced')),
  nationality text, tin text, occupation text, notes text,
  created_by uuid references public.profiles(id),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((buyer_type = 'individual' and nullif(trim(first_name),'') is not null and nullif(trim(last_name),'') is not null)
      or (buyer_type = 'corporate'  and nullif(trim(company_name),'') is not null))
);
create index buyers_owner_idx on public.buyers (owner_id) where deleted_at is null;
create index buyers_org_idx   on public.buyers (organization_id) where deleted_at is null;
create index buyers_name_idx  on public.buyers (organization_id, lower(last_name), lower(first_name));
create index buyers_email_idx on public.buyers (organization_id, lower(email));
-- Deliberately no UNIQUE(email/tin): a unique index would leak the existence of other agents' private buyers.

create table public.buyer_addresses (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.buyers(id),
  address_type text not null default 'home' check (address_type in ('home','work','billing','mailing','other')),
  line1 text not null check (length(trim(line1)) > 0),
  line2 text, barangay text,
  city text not null, province text, postal_code text,
  country text not null default 'PH' check (length(country) = 2),
  is_primary boolean not null default false,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index buyer_addresses_primary_uq on public.buyer_addresses (buyer_id, address_type) where is_primary and deleted_at is null;
create index buyer_addresses_buyer_idx on public.buyer_addresses (buyer_id) where deleted_at is null;

-- Explicit authorization to see/edit another salesperson's buyer.
create table public.buyer_access_grants (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.buyers(id),
  granted_to uuid not null references public.profiles(id),
  granted_by uuid not null references public.profiles(id),
  can_edit boolean not null default false,
  reason text,
  expires_at timestamptz,
  revoked_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (granted_to <> granted_by)
);
create unique index buyer_grants_active_uq on public.buyer_access_grants (buyer_id, granted_to) where revoked_at is null;
create index buyer_grants_to_idx on public.buyer_access_grants (granted_to) where revoked_at is null;

create table public.lead_sources (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  name text not null check (length(trim(name)) > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index lead_sources_name_uq on public.lead_sources (organization_id, lower(name));

create table public.leads (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  project_id uuid references public.projects(id),
  assigned_to uuid not null references public.profiles(id),
  created_by uuid not null references public.profiles(id),
  buyer_id uuid references public.buyers(id),                    -- set when converted
  source_id uuid references public.lead_sources(id),
  interested_lot_id uuid references public.lots(id),
  full_name text not null check (length(trim(full_name)) > 0),
  email text check (email is null or email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  phone text,
  budget_min numeric(14,2) check (budget_min is null or budget_min >= 0),
  budget_max numeric(14,2),
  status public.lead_status not null default 'new',
  lost_reason text,
  converted_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (budget_max is null or budget_min is null or budget_max >= budget_min),
  check (status <> 'lost' or nullif(trim(lost_reason),'') is not null),
  check (status <> 'converted' or buyer_id is not null)
);
create index leads_assigned_idx on public.leads (assigned_to, status) where deleted_at is null;
create index leads_project_idx  on public.leads (project_id, status) where deleted_at is null;
create index leads_buyer_idx    on public.leads (buyer_id);

create table public.lead_activities (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id),
  activity_type public.activity_type not null,
  subject text, notes text,
  activity_at timestamptz not null default now(),
  next_follow_up_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index lead_activities_lead_idx on public.lead_activities (lead_id, activity_at desc);
create index lead_activities_followup_idx on public.lead_activities (next_follow_up_at) where next_follow_up_at is not null;

comment on table public.buyers is 'Private buyer records owned by one salesperson. Visible to others only via grants, own transactions, or manager/accounting roles on a linked project.';
comment on table public.buyer_addresses is 'Buyer addresses; one primary per (buyer,type). Visibility follows the buyer.';
comment on table public.buyer_access_grants is 'Explicit, expiring, revocable permission to view/edit another salesperson''s buyer.';
comment on table public.leads is 'CRM leads. Visible to assignee, creator, project managers and admins.';
comment on table public.lead_activities is 'Calls, visits, notes and follow-ups against a lead.';
