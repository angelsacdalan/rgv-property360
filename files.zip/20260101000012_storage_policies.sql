-- RGV Property360 :: 012 Supabase Storage policies for the private 'documents' bucket.
-- No-op on plain PostgreSQL. Workflow: INSERT the public.documents row first (RLS validates the user may attach it),
-- then upload to storage using the same path. Storage access mirrors documents RLS.
do $$ begin
  if to_regclass('storage.objects') is null then raise notice 'storage schema not found, skipping'; return; end if;
  insert into storage.buckets (id, name, public) values ('documents','documents', false) on conflict (id) do nothing;
  execute $p$create policy documents_read on storage.objects for select to authenticated
    using (bucket_id = 'documents' and exists (select 1 from public.documents d where d.storage_bucket = bucket_id and d.storage_path = name))$p$;
  execute $p$create policy documents_upload on storage.objects for insert to authenticated
    with check (bucket_id = 'documents' and exists (select 1 from public.documents d where d.storage_bucket = bucket_id and d.storage_path = name and d.uploaded_by = auth.uid()))$p$;
  -- deliberately no UPDATE/DELETE policies: files are immutable; retire via documents.deleted_at
end $$;
