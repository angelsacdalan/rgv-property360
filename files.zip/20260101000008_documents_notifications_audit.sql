-- RGV Property360 :: 008 Documents, notifications, audit logs, triggers
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  project_id uuid references public.projects(id),
  buyer_id uuid references public.buyers(id),
  lot_id uuid references public.lots(id),
  reservation_id uuid references public.reservations(id),
  sale_id uuid references public.sales(id),
  payment_id uuid references public.payments(id),
  document_type public.document_type not null default 'other',
  title text not null check (length(trim(title)) > 0),
  storage_bucket text not null default 'documents',
  storage_path text not null check (length(storage_path) > 0),
  mime_type text,
  size_bytes bigint check (size_bytes is null or size_bytes >= 0),
  checksum_sha256 text check (checksum_sha256 is null or checksum_sha256 ~ '^[0-9a-f]{64}$'),
  version int not null default 1 check (version > 0),
  is_confidential boolean not null default false,
  uploaded_by uuid not null references public.profiles(id),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (num_nonnulls(project_id, buyer_id, lot_id, reservation_id, sale_id, payment_id) >= 1)
);
create unique index documents_path_uq on public.documents (storage_bucket, storage_path);
create index documents_buyer_idx on public.documents (buyer_id) where deleted_at is null;
create index documents_sale_idx on public.documents (sale_id) where deleted_at is null;
create index documents_project_idx on public.documents (project_id) where deleted_at is null;
create index documents_lot_idx on public.documents (lot_id) where deleted_at is null;

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  type text not null,
  title text not null,
  body text,
  entity_table text,
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_unread_idx on public.notifications (user_id, created_at desc) where read_at is null;
create index notifications_user_idx on public.notifications (user_id, created_at desc);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid,
  actor_id uuid,                       -- auth.uid(); NULL for service_role / system jobs
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  table_name text not null,
  record_id uuid,
  old_data jsonb,
  new_data jsonb,
  changed_fields text[],
  created_at timestamptz not null default now()
);
create index audit_logs_record_idx on public.audit_logs (table_name, record_id, created_at desc);
create index audit_logs_actor_idx  on public.audit_logs (actor_id, created_at desc);
create index audit_logs_created_idx on public.audit_logs (created_at desc);
create index audit_logs_org_idx on public.audit_logs (organization_id, created_at desc);

comment on table public.documents is 'Metadata for files in Supabase Storage, linked to at least one business entity.';
comment on table public.notifications is 'In-app notifications; created by workflow functions, readable only by the recipient.';
comment on table public.audit_logs is 'Append-only change log written by triggers. Readable by admins only.';

-- ---------- audit trigger ----------
create function app.audit() returns trigger language plpgsql security definer set search_path = '' as $$
declare o jsonb; n jsonb; chg text[]; rid uuid; org uuid;
begin
  o := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end;
  n := case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end;
  if tg_op = 'UPDATE' then
    select array_agg(k) into chg from jsonb_object_keys(n) k
     where k <> 'updated_at' and (n -> k) is distinct from (o -> k);
    if chg is null then return new; end if;     -- only updated_at changed
  end if;
  rid := coalesce(n ->> 'id', o ->> 'id')::uuid;
  org := coalesce(n ->> 'organization_id', o ->> 'organization_id')::uuid;
  insert into public.audit_logs (organization_id, actor_id, action, table_name, record_id, old_data, new_data, changed_fields)
  values (org, auth.uid(), tg_op, tg_table_name, rid, o, n, chg);
  return coalesce(new, old);
end $$;

-- ---------- updated_at ----------
do $$ declare t text; begin
  for t in select c.table_name from information_schema.columns c
           join information_schema.tables tb on tb.table_schema = c.table_schema and tb.table_name = c.table_name and tb.table_type = 'BASE TABLE'
           where c.table_schema = 'public' and c.column_name = 'updated_at' loop
    execute format('create trigger trg_%1$s_updated_at before update on public.%1$I for each row execute function app.set_updated_at()', t);
  end loop;
end $$;

-- ---------- audit on business tables ----------
do $$ declare t text; begin
  foreach t in array array['organizations','profiles','user_roles','project_members','projects','phases','blocks','lots','lot_prices',
    'buyers','buyer_addresses','buyer_access_grants','leads','reservations','approvals','sales','payment_schedules','payments',
    'payment_allocations','commission_rules','commissions','documents'] loop
    execute format('create trigger trg_%1$s_audit after insert or update or delete on public.%1$I for each row execute function app.audit()', t);
  end loop;
end $$;

-- ---------- financial/ledger records can never be deleted or truncated ----------
do $$ declare t text; begin
  foreach t in array array['payments','payment_allocations','payment_schedules','sales','reservations','approvals','commissions',
    'lot_prices','lot_status_history','audit_logs','buyers','lots','projects','organizations','profiles','documents','doc_counters'] loop
    execute format('create trigger trg_%1$s_nodelete before delete on public.%1$I for each row execute function app.prevent_delete()', t);
    execute format('create trigger trg_%1$s_notruncate before truncate on public.%1$I for each statement execute function app.prevent_delete()', t);
  end loop;
end $$;

-- ---------- append-only ----------
create trigger trg_audit_logs_immutable before update on public.audit_logs for each row execute function app.prevent_modify();
create trigger trg_lot_status_history_immutable before update on public.lot_status_history for each row execute function app.prevent_modify();
create trigger trg_payment_allocations_immutable before update on public.payment_allocations for each row execute function app.prevent_modify();

-- lot_prices: only effective_to may be set (closing a period)
create function app.guard_lot_prices() returns trigger language plpgsql as $$
begin
  if (new.lot_id, new.price, new.effective_from, new.set_by, new.project_id) is distinct from
     (old.lot_id, old.price, old.effective_from, old.set_by, old.project_id) then
    raise exception 'lot_prices history is immutable (only effective_to can be set)' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_lot_prices_guard before update on public.lot_prices for each row execute function app.guard_lot_prices();

-- payments: immutable receipt; only posted -> void transition allowed
create function app.guard_payments() returns trigger language plpgsql as $$
begin
  if old.status = 'void' then raise exception 'Voided payments cannot be modified' using errcode = '42501'; end if;
  if (new.organization_id, new.project_id, new.sale_id, new.buyer_id, new.receipt_no, new.amount, new.method, new.paid_at, new.recorded_by)
     is distinct from
     (old.organization_id, old.project_id, old.sale_id, old.buyer_id, old.receipt_no, old.amount, old.method, old.paid_at, old.recorded_by) then
    raise exception 'Posted payments are immutable; void and re-record instead' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_payments_guard before update on public.payments for each row execute function app.guard_payments();

-- lots: record status history; protect geometry of reserved/sold lots
create function app.lots_status_log() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.lot_status_history (lot_id, project_id, old_status, new_status, reason, reservation_id, sale_id, changed_by)
  values (new.id, new.project_id, old.status, new.status,
          nullif(current_setting('app.status_reason', true), ''),
          nullif(current_setting('app.ref_reservation', true), '')::uuid,
          nullif(current_setting('app.ref_sale', true), '')::uuid,
          auth.uid());
  return new;
end $$;
create trigger trg_lots_status_log after update of status on public.lots
  for each row when (old.status is distinct from new.status) execute function app.lots_status_log();

create function app.guard_lots() returns trigger language plpgsql as $$
begin
  if old.status in ('reserved','sold') and (new.area_sqm is distinct from old.area_sqm or new.block_id is distinct from old.block_id) then
    raise exception 'Area/block of a reserved or sold lot cannot be changed' using errcode = '23514';
  end if;
  return new;
end $$;
create trigger trg_lots_guard before update on public.lots for each row execute function app.guard_lots();

-- profiles: non-admins may not change their own org/status/department/email
create function app.guard_profiles() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not app.is_admin() and
     (new.organization_id, new.department_id, new.is_active, new.employee_no, new.email, new.deleted_at)
     is distinct from (old.organization_id, old.department_id, old.is_active, old.employee_no, old.email, old.deleted_at) then
    raise exception 'Only administrators can change these profile fields' using errcode = '42501';
  end if;
  return new;
end $$;
-- (trigger attached in 009 after app.is_admin() exists)
