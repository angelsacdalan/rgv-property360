-- RGV Property360 :: TEST SEED DATA (never run in production)
-- Deterministic ids: md5('seed:<key>')::uuid. All login passwords: Test1234!
-- No lot polygons are seeded: geometry must come from real project layouts.
do $$ begin
  if exists (select 1 from public.organizations where code not like 'TEST-%') then
    raise exception 'Refusing to seed: non-test organizations exist.'; end if;
end $$;

create function pg_temp.sid(k text) returns uuid language sql immutable as $$ select md5('seed:' || k)::uuid $$;

insert into public.organizations (id, code, name) values
  (pg_temp.sid('org1'), 'TEST-RGV',  'RGV Test Realty Corp'),
  (pg_temp.sid('org2'), 'TEST-OTHER','Other Test Developer Inc');
insert into public.departments (id, organization_id, name) values
  (pg_temp.sid('dept_sales'), pg_temp.sid('org1'), 'Sales'),
  (pg_temp.sid('dept_acct'),  pg_temp.sid('org1'), 'Accounting'),
  (pg_temp.sid('dept_legal'), pg_temp.sid('org1'), 'Legal & Documentation'),
  (pg_temp.sid('dept_mgmt'),  pg_temp.sid('org1'), 'Management');

-- users: key, email, org, dept, role
create temp table seed_users (k text, email text, org text, dept text, role public.app_role, name text);
insert into seed_users values
 ('sa',     'superadmin@test.rgv', 'org1','dept_mgmt','super_admin',      'Sam Super (TEST)'),
 ('admin',  'admin@test.rgv',      'org1','dept_mgmt','admin',            'Ada Admin (TEST)'),
 ('pm1',    'pm1@test.rgv',        'org1','dept_mgmt','project_manager',  'Paolo Manager A (TEST)'),
 ('sm1',    'sm1@test.rgv',        'org1','dept_sales','sales_manager',   'Sofia SalesMgr (TEST)'),
 ('sp1',    'sp1@test.rgv',        'org1','dept_sales','salesperson',     'Sales One (TEST)'),
 ('sp2',    'sp2@test.rgv',        'org1','dept_sales','salesperson',     'Sales Two (TEST)'),
 ('sp3',    'sp3@test.rgv',        'org1','dept_sales','salesperson',     'Sales Three, Project B (TEST)'),
 ('acct',   'acct@test.rgv',       'org1','dept_acct','accounting',       'Alma Accounting (TEST)'),
 ('docs',   'docs@test.rgv',       'org1','dept_legal','documents_officer','Dino Documents (TEST)'),
 ('viewer', 'viewer@test.rgv',     'org1','dept_mgmt','viewer',           'Vera Viewer (TEST)'),
 ('admin2', 'admin@other.test',    'org2', null,       'admin',           'Other Org Admin (TEST)');

insert into auth.users (id, instance_id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
                        created_at, updated_at, confirmation_token, recovery_token, email_change_token_new, email_change)
select pg_temp.sid(k), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', email,
       extensions.crypt('Test1234!', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{}', now(), now(), '', '', '', ''
from seed_users;
insert into public.profiles (id, organization_id, department_id, full_name, email)
select pg_temp.sid(k), pg_temp.sid(org), case when dept is null then null else pg_temp.sid(dept) end, name, email from seed_users;
insert into public.user_roles (user_id, role) select pg_temp.sid(k), role from seed_users;

insert into public.projects (id, organization_id, code, name, location, status, map_width, map_height) values
  (pg_temp.sid('projA'), pg_temp.sid('org1'), 'TEST-A', 'Test Heights (Project A)',  'Batangas, PH (test)', 'selling', 1000, 700),
  (pg_temp.sid('projB'), pg_temp.sid('org1'), 'TEST-B', 'Test Gardens (Project B)',  'Batangas, PH (test)', 'selling', 1000, 700),
  (pg_temp.sid('projC'), pg_temp.sid('org2'), 'TEST-C', 'Other Org Project C',       'Elsewhere (test)',    'selling', 1000, 700);
-- assignments
insert into public.project_members (project_id, user_id)
select pg_temp.sid(p), pg_temp.sid(u) from (values
  ('projA','pm1'),('projA','sm1'),('projA','sp1'),('projA','sp2'),('projA','acct'),('projA','docs'),('projA','viewer'),
  ('projB','sm1'),('projB','sp3'),('projB','acct')) m(p,u);

insert into public.phases (id, project_id, name, sequence, status) values
  (pg_temp.sid('phA1'), pg_temp.sid('projA'), 'Phase 1', 1, 'open'),
  (pg_temp.sid('phA2'), pg_temp.sid('projA'), 'Phase 2', 2, 'planned'),
  (pg_temp.sid('phB1'), pg_temp.sid('projB'), 'Phase 1', 1, 'open'),
  (pg_temp.sid('phC1'), pg_temp.sid('projC'), 'Phase 1', 1, 'open');
insert into public.blocks (id, project_id, phase_id, name) values
  (pg_temp.sid('blkA1'), pg_temp.sid('projA'), pg_temp.sid('phA1'), 'Block 1'),
  (pg_temp.sid('blkA2'), pg_temp.sid('projA'), pg_temp.sid('phA1'), 'Block 2'),
  (pg_temp.sid('blkB1'), pg_temp.sid('projB'), pg_temp.sid('phB1'), 'Block 1'),
  (pg_temp.sid('blkC1'), pg_temp.sid('projC'), pg_temp.sid('phC1'), 'Block 1');

-- lots (seed runs as table owner, so status/price are written directly; real users must use set_lot_price()).
create temp table seed_lots (k text, proj text, ph text, blk text, no text, area numeric, price numeric, st public.lot_status);
insert into seed_lots values
 ('lotA1','projA','phA1','blkA1','1',150,1500000,'available'),
 ('lotA2','projA','phA1','blkA1','2',180,1800000,'available'),
 ('lotA3','projA','phA1','blkA1','3',200,2000000,'available'),
 ('lotA4','projA','phA1','blkA2','1',220,2200000,'available'),
 ('lotA5','projA','phA1','blkA2','2',160,1600000,'available'),
 ('lotA6','projA','phA1','blkA2','3',175,null,'unavailable'),
 ('lotB1','projB','phB1','blkB1','1',140,1400000,'available'),
 ('lotB2','projB','phB1','blkB1','2',145,1450000,'available'),
 ('lotB3','projB','phB1','blkB1','3',150,null,'unavailable'),
 ('lotC1','projC','phC1','blkC1','1',300,3000000,'available');
insert into public.lots (id, project_id, phase_id, block_id, lot_number, area_sqm, current_price, status)
select pg_temp.sid(k), pg_temp.sid(proj), pg_temp.sid(ph), pg_temp.sid(blk), no, area, price, st from seed_lots;
insert into public.lot_prices (lot_id, project_id, price, effective_from, reason)
select pg_temp.sid(k), pg_temp.sid(proj), price, now() - interval '30 days', 'Initial price list (test seed)' from seed_lots where price is not null;

insert into public.commission_rules (project_id, name, rate_pct) values
  (pg_temp.sid('projA'), 'Standard 5%', 5.00), (pg_temp.sid('projB'), 'Standard 4%', 4.00);

insert into public.lead_sources (id, organization_id, name) values
  (pg_temp.sid('src_walkin'), pg_temp.sid('org1'), 'Walk-in'), (pg_temp.sid('src_fb'), pg_temp.sid('org1'), 'Facebook');

insert into public.buyers (id, organization_id, owner_id, created_by, buyer_type, first_name, last_name, email, mobile, civil_status, company_name) values
  (pg_temp.sid('buyer_sp1'), pg_temp.sid('org1'), pg_temp.sid('sp1'), pg_temp.sid('sp1'), 'individual', 'Bea',  'Buyer-One (TEST)',   'bea@example.test',  '0917-000-0001', 'single', null),
  (pg_temp.sid('buyer_sp2'), pg_temp.sid('org1'), pg_temp.sid('sp2'), pg_temp.sid('sp2'), 'individual', 'Carl', 'Buyer-Two (TEST)',   'carl@example.test', '0917-000-0002', 'married', null),
  (pg_temp.sid('buyer_sp3'), pg_temp.sid('org1'), pg_temp.sid('sp3'), pg_temp.sid('sp3'), 'individual', 'Dora', 'Buyer-Three (TEST)', 'dora@example.test', '0917-000-0003', 'single', null),
  (pg_temp.sid('buyer_corp'),pg_temp.sid('org1'), pg_temp.sid('sp1'), pg_temp.sid('sp1'), 'corporate', null, null, 'corp@example.test', '0917-000-0004', null, 'Test Holdings Inc (TEST)');
insert into public.buyer_addresses (buyer_id, address_type, line1, city, province, postal_code, is_primary) values
  (pg_temp.sid('buyer_sp1'), 'home', '1 Test St (TEST)', 'Batangas City', 'Batangas', '4200', true),
  (pg_temp.sid('buyer_sp2'), 'home', '2 Test St (TEST)', 'Lipa City',     'Batangas', '4217', true),
  (pg_temp.sid('buyer_sp3'), 'home', '3 Test St (TEST)', 'Tanauan City',  'Batangas', '4232', true);

insert into public.leads (id, organization_id, project_id, assigned_to, created_by, source_id, full_name, phone, status, budget_min, budget_max) values
  (pg_temp.sid('lead_sp1'), pg_temp.sid('org1'), pg_temp.sid('projA'), pg_temp.sid('sp1'), pg_temp.sid('sp1'), pg_temp.sid('src_walkin'), 'Lead One (TEST)', '0918-000-0001', 'qualified', 1000000, 2000000),
  (pg_temp.sid('lead_sp2'), pg_temp.sid('org1'), pg_temp.sid('projA'), pg_temp.sid('sp2'), pg_temp.sid('sp2'), pg_temp.sid('src_fb'),     'Lead Two (TEST)', '0918-000-0002', 'new', null, null),
  (pg_temp.sid('lead_sp3'), pg_temp.sid('org1'), pg_temp.sid('projB'), pg_temp.sid('sp3'), pg_temp.sid('sp3'), pg_temp.sid('src_fb'),     'Lead Three (TEST)','0918-000-0003','contacted', null, null);
insert into public.lead_activities (lead_id, activity_type, subject, created_by, next_follow_up_at) values
  (pg_temp.sid('lead_sp1'), 'call', 'Intro call (TEST)', pg_temp.sid('sp1'), now() + interval '3 days'),
  (pg_temp.sid('lead_sp2'), 'site_visit', 'Visited model unit (TEST)', pg_temp.sid('sp2'), null);
