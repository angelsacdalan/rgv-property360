-- RGV Property360 :: 001 Extensions, shared types, shared trigger functions
create schema if not exists extensions;
create extension if not exists pgcrypto   with schema extensions;
create extension if not exists btree_gist with schema extensions;  -- exclusion constraint on price periods

-- 'app' holds internal helpers/trigger functions. It is NOT exposed through the API.
create schema if not exists app;

create type public.app_role as enum
  ('super_admin','admin','project_manager','sales_manager','salesperson','accounting','documents_officer','viewer');
create type public.project_status   as enum ('planning','pre_selling','selling','sold_out','closed');
create type public.phase_status     as enum ('planned','open','closed');
create type public.lot_status       as enum ('available','reserved','sold','unavailable','on_hold');
create type public.buyer_type       as enum ('individual','corporate');
create type public.lead_status      as enum ('new','contacted','qualified','site_visit','negotiation','converted','lost');
create type public.activity_type    as enum ('call','email','sms','meeting','site_visit','note');
create type public.reservation_status as enum ('pending_approval','approved','rejected','cancelled','expired','converted');
create type public.sale_status      as enum ('pending_approval','approved','rejected','cancelled','completed');
create type public.approval_status  as enum ('pending','approved','rejected');
create type public.financing_type   as enum ('cash','in_house','bank','pag_ibig');
create type public.schedule_item_type as enum ('reservation_fee','downpayment','amortization','balloon','other');
create type public.schedule_status  as enum ('pending','partial','paid','overdue','waived');
create type public.payment_method   as enum ('cash','check','bank_transfer','credit_card','online','other');
create type public.payment_status   as enum ('posted','void');
create type public.commission_status as enum ('pending','approved','paid','cancelled');
create type public.document_type    as enum ('id','proof_of_income','contract_to_sell','deed_of_sale','reservation_form','official_receipt','title','site_plan','other');

create function app.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

-- Ledger protection: blocks DELETE/TRUNCATE for everyone, including service_role/postgres.
create function app.prevent_delete() returns trigger language plpgsql as $$
begin
  raise exception 'Deleting from % is not allowed; use void/cancel/soft-delete workflows', tg_table_name
    using errcode = '42501';
end $$;

-- Append-only tables: blocks UPDATE and DELETE.
create function app.prevent_modify() returns trigger language plpgsql as $$
begin
  raise exception '% is append-only', tg_table_name using errcode = '42501';
end $$;
