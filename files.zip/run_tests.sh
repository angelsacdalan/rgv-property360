#!/usr/bin/env bash
# Builds a throw-away PostgreSQL database, applies stub + migrations + seed, then runs the RLS test suite.
# Usage: scripts/run_tests.sh      (needs postgresql server binaries; runs as a temp local cluster)
set -euo pipefail
cd "$(dirname "$0")/.."
PGBIN=$(ls -d /usr/lib/postgresql/*/bin | tail -1)
D=${PGDATA_TEST:-/tmp/rgv_pg}; PORT=${PGPORT_TEST:-54329}
if [ "$(id -u)" = 0 ]; then RUN="runuser -u postgres --"; chmod o+rx . ; else RUN=""; fi
if [ ! -d "$D" ]; then mkdir -p "$D"; [ "$(id -u)" = 0 ] && chown postgres "$D"; $RUN $PGBIN/initdb -D "$D" -A trust >/dev/null; fi
$RUN $PGBIN/pg_ctl -D "$D" -o "-p $PORT -k /tmp" -l /tmp/rgv_pg.log -w start >/dev/null 2>&1 || true
P="$RUN $PGBIN/psql -h /tmp -p $PORT -v ON_ERROR_STOP=1 -q -X"
$P -d postgres -c "drop database if exists rgv_test" -c "create database rgv_test" >/dev/null
$P -d rgv_test -f scripts/supabase_stub.sql
for f in supabase/migrations/*.sql; do echo "== $f"; $P -d rgv_test -f "$f"; done
$P -d rgv_test -f supabase/seed.sql
$P -d rgv_test -v ON_ERROR_STOP=0 -v verbose=${VERBOSE:-off} -f supabase/tests/rls_tests.sql
$RUN $PGBIN/pg_ctl -D "$D" -m fast stop >/dev/null
