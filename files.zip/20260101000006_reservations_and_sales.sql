-- RGV Property360 :: 006 Reservations, approvals, sales
-- Per-organization document numbering. Row-locked upsert => gap-free, race-free under concurrency.
create table public.doc_counters (
  organization_id uuid not null references public.organizations(id),
  kind text not null,
  year int not null,
  last_value int not null default 0,
  primary key (organization_id, kind, year)
);

create table public.reservations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  project_id uuid not null,
  lot_id uuid not null,
  buyer_id uuid not null references public.buyers(id),
  agent_id uuid not null references public.profiles(id),
  created_by uuid not null references public.profiles(id),
  reservation_no text not null,
  status public.reservation_status not null default 'pending_approval',
  reservation_fee numeric(14,2) not null default 0 check (reservation_fee >= 0),
  reserved_at timestamptz not null default now(),
  expires_at timestamptz not null,
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  rejection_reason text,
  cancelled_by uuid references public.profiles(id),
  cancelled_at timestamptz,
  cancel_reason text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (lot_id, project_id) references public.lots(id, project_id),
  check (expires_at > reserved_at),
  check (status not in ('approved','converted') or (approved_by is not null and approved_at is not null)),
  check (approved_by is null or approved_by <> agent_id),                       -- maker-checker
  check (status <> 'rejected'  or nullif(trim(rejection_reason),'') is not null),
  check (status <> 'cancelled' or (cancelled_at is not null and nullif(trim(cancel_reason),'') is not null))
);
create unique index reservations_no_uq on public.reservations (organization_id, reservation_no);
-- A lot can have only ONE live reservation at any time (DB-level double-booking guard).
create unique index reservations_one_active_per_lot on public.reservations (lot_id) where status in ('pending_approval','approved');
create index reservations_project_idx on public.reservations (project_id, status);
create index reservations_buyer_idx on public.reservations (buyer_id);
create index reservations_agent_idx on public.reservations (agent_id);
create index reservations_expiry_idx on public.reservations (expires_at) where status in ('pending_approval','approved');
create unique index reservations_id_project_uq on public.reservations (id, project_id);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  project_id uuid not null,
  lot_id uuid not null,
  buyer_id uuid not null references public.buyers(id),
  reservation_id uuid not null references public.reservations(id),
  agent_id uuid not null references public.profiles(id),
  created_by uuid not null references public.profiles(id),
  sale_no text not null,
  status public.sale_status not null default 'pending_approval',
  list_price numeric(14,2) not null check (list_price >= 0),            -- snapshot of lot price at time of sale
  discount numeric(14,2) not null default 0 check (discount >= 0),
  net_price numeric(14,2) generated always as (list_price - discount) stored,
  financing_type public.financing_type not null,
  downpayment_pct numeric(5,2) not null check (downpayment_pct between 0 and 100),
  downpayment_amount numeric(14,2) generated always as (round((list_price - discount) * downpayment_pct / 100, 2)) stored,
  term_months int not null default 0 check (term_months between 0 and 360),
  interest_rate_pct numeric(6,3) not null default 0 check (interest_rate_pct between 0 and 100),
  first_due_date date not null,
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  rejection_reason text,
  cancelled_at timestamptz,
  cancel_reason text,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (lot_id, project_id) references public.lots(id, project_id),
  foreign key (reservation_id, project_id) references public.reservations(id, project_id),
  check (discount <= list_price),
  check (downpayment_pct = 100 or term_months > 0),
  check (financing_type <> 'cash' or downpayment_pct = 100),
  check (status not in ('approved','completed') or (approved_by is not null and approved_at is not null)),
  check (approved_by is null or (approved_by <> agent_id and approved_by <> created_by)),   -- maker-checker
  check (status <> 'rejected'  or nullif(trim(rejection_reason),'') is not null),
  check (status <> 'cancelled' or nullif(trim(cancel_reason),'') is not null)
);
create unique index sales_no_uq on public.sales (organization_id, sale_no);
create unique index sales_one_active_per_lot on public.sales (lot_id) where status in ('pending_approval','approved','completed');
create unique index sales_one_active_per_reservation on public.sales (reservation_id) where status in ('pending_approval','approved','completed');
create index sales_project_idx on public.sales (project_id, status);
create index sales_buyer_idx on public.sales (buyer_id);
create index sales_agent_idx on public.sales (agent_id);
create unique index sales_id_project_uq on public.sales (id, project_id);

-- Approval trail: exactly one of reservation_id / sale_id.
create table public.approvals (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id),
  reservation_id uuid references public.reservations(id),
  sale_id uuid references public.sales(id),
  status public.approval_status not null default 'pending',
  requested_by uuid not null references public.profiles(id),
  decided_by uuid references public.profiles(id),
  decided_at timestamptz,
  comments text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (num_nonnulls(reservation_id, sale_id) = 1),
  check ((status = 'pending') = (decided_by is null)),
  check (decided_by is null or decided_by <> requested_by)
);
create index approvals_pending_idx on public.approvals (project_id) where status = 'pending';
create index approvals_reservation_idx on public.approvals (reservation_id);
create index approvals_sale_idx on public.approvals (sale_id);

alter table public.lot_status_history
  add constraint lot_status_history_reservation_fk foreign key (reservation_id) references public.reservations(id),
  add constraint lot_status_history_sale_fk foreign key (sale_id) references public.sales(id);

comment on table public.reservations is 'Lot reservation. Lifecycle: pending_approval -> approved -> converted | rejected | cancelled | expired. Partial unique index blocks double booking.';
comment on table public.sales is 'Sale/contract. Prices are snapshots; net_price and downpayment_amount are generated columns. Maker-checker enforced by CHECK.';
comment on table public.approvals is 'Approval trail for reservations and sales. Approver must differ from requester.';
comment on table public.doc_counters is 'Per-organization yearly counters for RSV/SAL/OR numbering.';
