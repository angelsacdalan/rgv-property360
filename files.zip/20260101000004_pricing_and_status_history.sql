-- RGV Property360 :: 004 Price history and lot status history (both append-only ledgers)
create table public.lot_prices (
  id uuid primary key default gen_random_uuid(),
  lot_id uuid not null,
  project_id uuid not null,
  price numeric(14,2) not null check (price >= 0),
  effective_from timestamptz not null default now(),
  effective_to timestamptz,
  reason text,
  set_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  foreign key (lot_id, project_id) references public.lots(id, project_id),
  check (effective_to is null or effective_to > effective_from),
  -- a lot can never have two overlapping price periods
  constraint lot_prices_no_overlap exclude using gist
    (lot_id with =, tstzrange(effective_from, effective_to, '[)') with &&)
);
create index lot_prices_lot_idx on public.lot_prices (lot_id, effective_from desc);
create index lot_prices_project_idx on public.lot_prices (project_id);

create table public.lot_status_history (
  id uuid primary key default gen_random_uuid(),
  lot_id uuid not null,
  project_id uuid not null,
  old_status public.lot_status,
  new_status public.lot_status not null,
  reason text,
  reservation_id uuid,            -- FK added in 006 (tables don't exist yet)
  sale_id uuid,                   -- FK added in 006
  changed_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  foreign key (lot_id, project_id) references public.lots(id, project_id)
);
create index lot_status_history_lot_idx on public.lot_status_history (lot_id, created_at desc);
create index lot_status_history_project_idx on public.lot_status_history (project_id, created_at desc);

comment on table public.lot_prices is 'Price history. Exclusion constraint prevents overlapping periods. Only set_lot_price() writes here.';
comment on table public.lot_status_history is 'Immutable log of every lot status change, written by trigger on lots.';
