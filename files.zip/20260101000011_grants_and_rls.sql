-- RGV Property360 :: 011 Privileges + Row Level Security
-- Layered defence:  (1) GRANTs/column grants  (2) RLS policies  (3) SECURITY DEFINER workflow functions re-check roles
-- (4) triggers/constraints that even service_role cannot bypass (ledger immutability, no deletes).

-- ---------- 1. privileges ----------
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
revoke all on all functions in schema app    from public, anon, authenticated;
grant usage on schema public to authenticated;
grant usage on schema app    to authenticated;
-- policy helpers must be callable by the role evaluating policies
grant execute on function app.org_id(), app.has_any_role(public.app_role[]), app.has_role(public.app_role), app.is_admin(),
  app.is_project_member(uuid), app.can_access_project(uuid), app.has_project_role(uuid, public.app_role[]), app.is_approver(uuid),
  app.can_view_scope(uuid, uuid), app.can_view_sale(uuid), app.can_view_reservation(uuid), app.can_view_buyer(uuid),
  app.can_edit_buyer(uuid), app.can_view_lead(uuid, uuid, uuid), app.can_view_lead_id(uuid),
  app.can_view_document(uuid,uuid,uuid,uuid,uuid,uuid,uuid,uuid,boolean) to authenticated;
-- workflow RPCs (the only write path for prices, status, reservations, sales, payments, commissions)
grant execute on function
  public.set_lot_price(uuid, numeric, text), public.set_lot_availability(uuid, public.lot_status, text),
  public.create_reservation(uuid, uuid, numeric, timestamptz, text), public.decide_reservation(uuid, boolean, text),
  public.cancel_reservation(uuid, text),
  public.create_sale_from_reservation(uuid, numeric, numeric, public.financing_type, int, numeric, date),
  public.decide_sale(uuid, boolean, text), public.record_payment(uuid, numeric, public.payment_method, text, timestamptz, text),
  public.void_payment(uuid, text), public.approve_commission(uuid), public.pay_commission(uuid, text),
  public.grant_buyer_access(uuid, uuid, boolean, timestamptz, text), public.revoke_buyer_access(uuid),
  public.transfer_buyer(uuid, uuid), public.soft_delete(text, uuid, text), public.restore_record(text, uuid) to authenticated;
-- expire_reservations() / mark_overdue_schedules(): service_role / pg_cron only (no grant to API roles)

-- Read access (rows still filtered by RLS)
grant select on public.organizations, public.departments, public.profiles, public.user_roles, public.project_members,
  public.projects, public.phases, public.blocks, public.lots, public.lot_prices, public.lot_status_history,
  public.buyers, public.buyer_addresses, public.buyer_access_grants, public.lead_sources, public.leads, public.lead_activities,
  public.reservations, public.approvals, public.sales, public.payment_schedules, public.payments, public.payment_allocations,
  public.commission_rules, public.commissions, public.documents, public.notifications, public.audit_logs to authenticated;

-- Direct writes: master data only. No DELETE is granted on anything. Soft delete = soft_delete(); revocation = revoked_at/removed_at.
grant update (name) on public.organizations to authenticated;
grant insert, update on public.departments to authenticated;
grant insert (id, organization_id, department_id, full_name, email, phone, employee_no) on public.profiles to authenticated;
grant update (department_id, full_name, email, phone, employee_no, is_active, deleted_at) on public.profiles to authenticated;
grant insert (user_id, role, granted_by) on public.user_roles to authenticated;
grant update (revoked_at) on public.user_roles to authenticated;
grant insert (project_id, user_id, assigned_by) on public.project_members to authenticated;
grant update (removed_at) on public.project_members to authenticated;
grant insert (organization_id, code, name, description, location, status, map_width, map_height, map_background_path, created_by) on public.projects to authenticated;
grant update (code, name, description, location, status, map_width, map_height, map_background_path, deleted_at) on public.projects to authenticated;
grant insert (project_id, name, sequence, status), update (name, sequence, status, deleted_at) on public.phases to authenticated;
grant insert (project_id, phase_id, name), update (name) on public.blocks to authenticated;
-- lots: NO column grant on current_price / status  => accounting, sales, even project managers cannot touch them directly
grant insert (project_id, phase_id, block_id, lot_number, area_sqm, description, notes, polygon) on public.lots to authenticated;
grant update (lot_number, area_sqm, description, notes, polygon) on public.lots to authenticated;
grant insert (organization_id, owner_id, buyer_type, first_name, middle_name, last_name, company_name, email, phone, mobile, birth_date,
              civil_status, nationality, tin, occupation, notes, created_by) on public.buyers to authenticated;
grant update (buyer_type, first_name, middle_name, last_name, company_name, email, phone, mobile, birth_date, civil_status,
              nationality, tin, occupation, notes) on public.buyers to authenticated;   -- owner_id only via transfer_buyer()
grant insert, update (address_type, line1, line2, barangay, city, province, postal_code, country, is_primary) on public.buyer_addresses to authenticated;
grant insert, update on public.lead_sources to authenticated;
grant insert (organization_id, project_id, assigned_to, created_by, buyer_id, source_id, interested_lot_id, full_name, email, phone,
              budget_min, budget_max, status, lost_reason, converted_at) on public.leads to authenticated;
grant update (project_id, assigned_to, buyer_id, source_id, interested_lot_id, full_name, email, phone, budget_min, budget_max,
              status, lost_reason, converted_at) on public.leads to authenticated;
grant insert (lead_id, activity_type, subject, notes, activity_at, next_follow_up_at, created_by) on public.lead_activities to authenticated;
grant update (subject, notes, activity_at, next_follow_up_at) on public.lead_activities to authenticated;
grant insert (project_id, name, rate_pct, applies_from, is_active), update (name, rate_pct, applies_from, is_active) on public.commission_rules to authenticated;
grant insert (organization_id, project_id, buyer_id, lot_id, reservation_id, sale_id, payment_id, document_type, title, storage_bucket,
              storage_path, mime_type, size_bytes, checksum_sha256, is_confidential, uploaded_by) on public.documents to authenticated;
grant update (title, document_type, is_confidential) on public.documents to authenticated;
grant update (read_at) on public.notifications to authenticated;
-- reservations, approvals, sales, payment_schedules, payments, payment_allocations, commissions,
-- lot_prices, lot_status_history, audit_logs, doc_counters: SELECT only (writes via RPC / triggers).

-- ---------- 2. RLS ----------
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;
-- doc_counters has RLS on and no policy => invisible to API roles.

create policy organizations_select on public.organizations for select to authenticated using (id = app.org_id());
create policy organizations_update on public.organizations for update to authenticated
  using (id = app.org_id() and app.is_admin()) with check (id = app.org_id() and app.is_admin());

create policy departments_select on public.departments for select to authenticated using (organization_id = app.org_id());
create policy departments_insert on public.departments for insert to authenticated with check (organization_id = app.org_id() and app.is_admin());
create policy departments_update on public.departments for update to authenticated
  using (organization_id = app.org_id() and app.is_admin()) with check (organization_id = app.org_id() and app.is_admin());

create policy profiles_select on public.profiles for select to authenticated using (organization_id = app.org_id());
create policy profiles_insert on public.profiles for insert to authenticated with check (organization_id = app.org_id() and app.is_admin());
create policy profiles_update on public.profiles for update to authenticated
  using (organization_id = app.org_id() and (id = auth.uid() or app.is_admin()))
  with check (organization_id = app.org_id() and (id = auth.uid() or app.is_admin()));

create policy user_roles_select on public.user_roles for select to authenticated
  using (user_id = auth.uid() or (app.is_admin() and exists (select 1 from public.profiles p where p.id = user_id and p.organization_id = app.org_id())));
-- only super_admin may grant/revoke admin-level roles; admins manage the rest
create policy user_roles_insert on public.user_roles for insert to authenticated
  with check (exists (select 1 from public.profiles p where p.id = user_id and p.organization_id = app.org_id())
              and ((role in ('super_admin','admin') and app.has_role('super_admin')) or (role not in ('super_admin','admin') and app.is_admin())));
create policy user_roles_update on public.user_roles for update to authenticated
  using (exists (select 1 from public.profiles p where p.id = user_id and p.organization_id = app.org_id())
         and ((role in ('super_admin','admin') and app.has_role('super_admin')) or (role not in ('super_admin','admin') and app.is_admin())))
  with check (true);

create policy project_members_select on public.project_members for select to authenticated
  using (user_id = auth.uid() or app.can_access_project(project_id));
create policy project_members_insert on public.project_members for insert to authenticated
  with check (app.has_project_role(project_id, array['project_manager']::public.app_role[])
              and exists (select 1 from public.profiles p where p.id = user_id and p.organization_id = app.org_id()));
create policy project_members_update on public.project_members for update to authenticated
  using (app.has_project_role(project_id, array['project_manager']::public.app_role[])) with check (true);

create policy projects_select on public.projects for select to authenticated
  using (app.can_access_project(id) and (deleted_at is null or app.is_admin()));
create policy projects_insert on public.projects for insert to authenticated with check (organization_id = app.org_id() and app.is_admin());
create policy projects_update on public.projects for update to authenticated
  using (organization_id = app.org_id() and app.is_admin()) with check (organization_id = app.org_id() and app.is_admin());

create policy phases_select on public.phases for select to authenticated using (app.can_access_project(project_id) and (deleted_at is null or app.is_admin()));
create policy phases_insert on public.phases for insert to authenticated with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy phases_update on public.phases for update to authenticated
  using (app.has_project_role(project_id, array['project_manager']::public.app_role[]))
  with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy blocks_select on public.blocks for select to authenticated using (app.can_access_project(project_id) and (deleted_at is null or app.is_admin()));
create policy blocks_insert on public.blocks for insert to authenticated with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy blocks_update on public.blocks for update to authenticated
  using (app.has_project_role(project_id, array['project_manager']::public.app_role[]))
  with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy lots_select on public.lots for select to authenticated using (app.can_access_project(project_id) and (deleted_at is null or app.is_admin()));
create policy lots_insert on public.lots for insert to authenticated with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy lots_update on public.lots for update to authenticated
  using (app.has_project_role(project_id, array['project_manager']::public.app_role[]))
  with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));

create policy lot_prices_select on public.lot_prices for select to authenticated using (app.can_access_project(project_id));
create policy lot_status_history_select on public.lot_status_history for select to authenticated using (app.can_access_project(project_id));

-- Buyers: private to owner unless authorized
create policy buyers_select on public.buyers for select to authenticated using (app.can_view_buyer(id));
create policy buyers_insert on public.buyers for insert to authenticated
  with check (organization_id = app.org_id() and owner_id = auth.uid() and created_by = auth.uid()
              and app.has_any_role(array['salesperson','sales_manager','project_manager','admin','super_admin']::public.app_role[]));
create policy buyers_update on public.buyers for update to authenticated
  using (app.can_edit_buyer(id)) with check (organization_id = app.org_id());
create policy buyer_addresses_select on public.buyer_addresses for select to authenticated using (app.can_view_buyer(buyer_id) and (deleted_at is null or app.is_admin()));
create policy buyer_addresses_insert on public.buyer_addresses for insert to authenticated with check (app.can_edit_buyer(buyer_id));
create policy buyer_addresses_update on public.buyer_addresses for update to authenticated using (app.can_edit_buyer(buyer_id)) with check (app.can_edit_buyer(buyer_id));
create policy buyer_grants_select on public.buyer_access_grants for select to authenticated
  using (granted_to = auth.uid() or granted_by = auth.uid() or app.can_edit_buyer(buyer_id));

-- CRM
create policy lead_sources_select on public.lead_sources for select to authenticated using (organization_id = app.org_id());
create policy lead_sources_insert on public.lead_sources for insert to authenticated
  with check (organization_id = app.org_id() and app.has_any_role(array['sales_manager','project_manager','admin','super_admin']::public.app_role[]));
create policy lead_sources_update on public.lead_sources for update to authenticated
  using (organization_id = app.org_id() and app.has_any_role(array['sales_manager','project_manager','admin','super_admin']::public.app_role[])) with check (organization_id = app.org_id());
create policy leads_select on public.leads for select to authenticated
  using (organization_id = app.org_id() and (deleted_at is null or app.is_admin()) and app.can_view_lead(project_id, assigned_to, created_by));
create policy leads_insert on public.leads for insert to authenticated
  with check (organization_id = app.org_id() and created_by = auth.uid()
    and app.has_any_role(array['salesperson','sales_manager','project_manager','admin','super_admin']::public.app_role[])
    and (project_id is null or app.can_access_project(project_id))
    and (assigned_to = auth.uid() or app.has_any_role(array['sales_manager','project_manager','admin','super_admin']::public.app_role[])));
create policy leads_update on public.leads for update to authenticated
  using (organization_id = app.org_id() and app.can_view_lead(project_id, assigned_to, created_by))
  with check (organization_id = app.org_id()
    and (assigned_to = auth.uid() or app.has_any_role(array['sales_manager','project_manager','admin','super_admin']::public.app_role[])));
create policy lead_activities_select on public.lead_activities for select to authenticated using (app.can_view_lead_id(lead_id));
create policy lead_activities_insert on public.lead_activities for insert to authenticated with check (created_by = auth.uid() and app.can_view_lead_id(lead_id));
create policy lead_activities_update on public.lead_activities for update to authenticated using (created_by = auth.uid()) with check (created_by = auth.uid());

-- Transactions (read-only through the API; writes via RPC)
create policy reservations_select on public.reservations for select to authenticated using (organization_id = app.org_id() and app.can_view_scope(project_id, agent_id));
create policy sales_select on public.sales for select to authenticated using (organization_id = app.org_id() and app.can_view_scope(project_id, agent_id));
create policy approvals_select on public.approvals for select to authenticated
  using ((reservation_id is not null and app.can_view_reservation(reservation_id)) or (sale_id is not null and app.can_view_sale(sale_id)));
create policy payment_schedules_select on public.payment_schedules for select to authenticated using (app.can_view_sale(sale_id));
create policy payments_select on public.payments for select to authenticated using (organization_id = app.org_id() and app.can_view_sale(sale_id));
create policy payment_allocations_select on public.payment_allocations for select to authenticated using (app.can_view_sale(sale_id));
create policy commission_rules_select on public.commission_rules for select to authenticated
  using (app.has_project_role(project_id, array['project_manager','sales_manager','accounting']::public.app_role[]));
create policy commission_rules_insert on public.commission_rules for insert to authenticated
  with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy commission_rules_update on public.commission_rules for update to authenticated
  using (app.has_project_role(project_id, array['project_manager']::public.app_role[])) with check (app.has_project_role(project_id, array['project_manager']::public.app_role[]));
create policy commissions_select on public.commissions for select to authenticated
  using (app.can_access_project(project_id) and (agent_id = auth.uid() or app.is_admin()
         or app.has_any_role(array['project_manager','sales_manager','accounting']::public.app_role[])));

-- Documents
create policy documents_select on public.documents for select to authenticated
  using ((deleted_at is null or app.is_admin())
         and app.can_view_document(organization_id, project_id, buyer_id, lot_id, reservation_id, sale_id, payment_id, uploaded_by, is_confidential));
create policy documents_insert on public.documents for insert to authenticated
  with check (uploaded_by = auth.uid() and organization_id = app.org_id()
    and app.has_any_role(array['salesperson','sales_manager','project_manager','accounting','documents_officer','admin','super_admin']::public.app_role[])
    -- the uploader shortcut is deliberately NOT used here: the user must be entitled to the TARGET entity
    and app.can_view_document(organization_id, project_id, buyer_id, lot_id, reservation_id, sale_id, payment_id, null, false));
create policy documents_update on public.documents for update to authenticated
  using (organization_id = app.org_id() and (uploaded_by = auth.uid() or app.is_admin()
         or app.has_any_role(array['documents_officer','sales_manager','project_manager']::public.app_role[])))
  with check (organization_id = app.org_id());

-- Notifications & audit
create policy notifications_select on public.notifications for select to authenticated using (user_id = auth.uid());
create policy notifications_update on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy audit_logs_select on public.audit_logs for select to authenticated using (app.is_admin() and organization_id = app.org_id());
