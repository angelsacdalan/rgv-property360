-- RGV Property360 :: 003 Projects, phases, blocks, lots (+ map geometry)
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  code text not null check (code ~ '^[A-Za-z0-9_-]{2,20}$'),
  name text not null check (length(trim(name)) > 0),
  description text,
  location text,
  status public.project_status not null default 'planning',
  -- map canvas used by the interactive lot map (polygon coordinates live in lots.polygon)
  map_width  numeric(12,2) check (map_width  is null or map_width  > 0),
  map_height numeric(12,2) check (map_height is null or map_height > 0),
  map_background_path text,
  created_by uuid references public.profiles(id),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index projects_code_uq on public.projects (organization_id, lower(code)) where deleted_at is null;
create index projects_org_idx on public.projects (organization_id) where deleted_at is null;

-- Project assignment: drives most RLS decisions.
create table public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id),
  user_id uuid not null references public.profiles(id),
  assigned_by uuid references public.profiles(id),
  removed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index project_members_active_uq on public.project_members (project_id, user_id) where removed_at is null;
create index project_members_user_idx on public.project_members (user_id) where removed_at is null;

create table public.phases (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id),
  name text not null check (length(trim(name)) > 0),
  sequence int not null check (sequence > 0),
  status public.phase_status not null default 'planned',
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id, project_id)
);
create unique index phases_seq_uq on public.phases (project_id, sequence) where deleted_at is null;
create unique index phases_name_uq on public.phases (project_id, lower(name)) where deleted_at is null;

create table public.blocks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null,
  phase_id uuid not null,
  name text not null check (length(trim(name)) > 0),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (phase_id, project_id) references public.phases(id, project_id),  -- block's phase must belong to same project
  unique (id, project_id),
  unique (id, phase_id)
);
create unique index blocks_name_uq on public.blocks (phase_id, lower(name)) where deleted_at is null;

create table public.lots (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null,
  phase_id uuid not null,
  block_id uuid not null,
  lot_number text not null check (length(trim(lot_number)) > 0),
  area_sqm numeric(10,2) not null check (area_sqm > 0),
  description text,
  notes text,
  -- Real outline as [[x,y],...] in the project's map canvas units. NULL = no geometry captured yet.
  -- Never auto-generated; any simple polygon (not just rectangles) is valid.
  polygon jsonb check (polygon is null or (jsonb_typeof(polygon) = 'array' and jsonb_array_length(polygon) >= 3)),
  -- current_price/status are NOT directly writable by API roles; see set_lot_price()/workflow functions.
  current_price numeric(14,2) check (current_price is null or current_price >= 0),
  status public.lot_status not null default 'unavailable',
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (block_id, project_id) references public.blocks(id, project_id),
  foreign key (block_id, phase_id)   references public.blocks(id, phase_id),
  unique (id, project_id),
  check (status in ('unavailable','on_hold') or current_price is not null)
);
create unique index lots_number_uq on public.lots (block_id, lower(lot_number)) where deleted_at is null;
create index lots_project_status_idx on public.lots (project_id, status) where deleted_at is null;
create index lots_phase_idx on public.lots (phase_id);

comment on table public.projects is 'Subdivision / development project. Soft-deleted via deleted_at.';
comment on table public.project_members is 'Assigns users to projects. RLS grants non-admin users access only to projects they are assigned to.';
comment on table public.phases is 'Project phase. (id, project_id) unique so children can enforce same-project integrity.';
comment on table public.blocks is 'Block within a phase; composite FK guarantees phase and block belong to the same project.';
comment on table public.lots is 'Sellable lot. polygon holds real map geometry; price/status change only through audited functions.';
