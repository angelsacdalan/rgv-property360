-- RGV Property360 :: 007 Payment schedules, payments, allocations, commissions
create table public.payment_schedules (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null,
  sale_id uuid not null,
  installment_no int not null check (installment_no > 0),
  item_type public.schedule_item_type not null,
  due_date date not null,
  amount_due numeric(14,2) not null check (amount_due >= 0),
  amount_paid numeric(14,2) not null default 0 check (amount_paid >= 0),
  status public.schedule_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (sale_id, project_id) references public.sales(id, project_id),
  unique (sale_id, installment_no),
  unique (id, sale_id),
  check (amount_paid <= amount_due)
);
create index payment_schedules_due_idx on public.payment_schedules (due_date) where status in ('pending','partial','overdue');
create index payment_schedules_project_idx on public.payment_schedules (project_id);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  project_id uuid not null,
  sale_id uuid not null,
  buyer_id uuid not null references public.buyers(id),
  receipt_no text not null,
  amount numeric(14,2) not null check (amount > 0),
  method public.payment_method not null,
  reference_no text,
  paid_at timestamptz not null default now(),
  status public.payment_status not null default 'posted',
  recorded_by uuid not null references public.profiles(id),
  voided_by uuid references public.profiles(id),
  voided_at timestamptz,
  void_reason text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (sale_id, project_id) references public.sales(id, project_id),
  unique (id, sale_id),
  check ((status = 'void') = (voided_at is not null and voided_by is not null and nullif(trim(void_reason),'') is not null))
);
create unique index payments_receipt_uq on public.payments (organization_id, receipt_no);
create index payments_sale_idx on public.payments (sale_id, paid_at);
create index payments_project_idx on public.payments (project_id, paid_at desc);
create index payments_buyer_idx on public.payments (buyer_id);
create index payments_method_ref_idx on public.payments (reference_no) where reference_no is not null;

create table public.payment_allocations (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null,
  schedule_id uuid not null,
  sale_id uuid not null,
  amount numeric(14,2) not null check (amount > 0),
  created_at timestamptz not null default now(),
  foreign key (payment_id, sale_id)  references public.payments(id, sale_id),
  foreign key (schedule_id, sale_id) references public.payment_schedules(id, sale_id),  -- payment and schedule must be the same sale
  unique (payment_id, schedule_id)
);
create index payment_allocations_schedule_idx on public.payment_allocations (schedule_id);
create index payment_allocations_sale_idx on public.payment_allocations (sale_id);

create table public.commission_rules (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id),
  name text not null,
  rate_pct numeric(5,2) not null check (rate_pct between 0 and 100),
  applies_from date not null default current_date,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index commission_rules_project_idx on public.commission_rules (project_id, applies_from desc) where is_active;

create table public.commissions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null,
  sale_id uuid not null,
  agent_id uuid not null references public.profiles(id),
  rate_pct numeric(5,2) not null check (rate_pct between 0 and 100),
  base_amount numeric(14,2) not null check (base_amount >= 0),
  amount numeric(14,2) generated always as (round(base_amount * rate_pct / 100, 2)) stored,
  status public.commission_status not null default 'pending',
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  paid_by uuid references public.profiles(id),
  paid_at timestamptz,
  payment_reference text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (sale_id, project_id) references public.sales(id, project_id),
  check (status <> 'approved' or (approved_by is not null and approved_at is not null)),
  check (status <> 'paid' or (approved_by is not null and paid_by is not null and paid_at is not null))
);
create unique index commissions_sale_agent_uq on public.commissions (sale_id, agent_id) where status <> 'cancelled';
create index commissions_agent_idx on public.commissions (agent_id, status);
create index commissions_project_idx on public.commissions (project_id, status);

comment on table public.payment_schedules is 'Installment plan per sale. amount_paid/status are maintained by triggers from allocations.';
comment on table public.payments is 'Posted receipts. Immutable except void; never deletable. Created only by record_payment().';
comment on table public.payment_allocations is 'Splits a payment across schedule lines. Composite FKs force payment, schedule and allocation to share one sale.';
comment on table public.commission_rules is 'Per-project commission percentage, newest applies_from wins.';
comment on table public.commissions is 'Agent commission per sale: pending -> approved (manager) -> paid (accounting).';
