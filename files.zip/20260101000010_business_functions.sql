-- RGV Property360 :: 010 Transaction-safe business operations (RPC).
-- Every function: SECURITY DEFINER, re-checks authorization itself, locks the rows it changes (FOR UPDATE),
-- and runs atomically in a single transaction. API roles have NO direct write access to prices, lot status,
-- reservations, sales, schedules, payments, allocations or commissions: these functions are the only door.

create function app.me() returns uuid language plpgsql stable as $$
declare u uuid := auth.uid();
begin
  if u is null or app.org_id() is null then raise exception 'Not authenticated' using errcode = '28000'; end if;
  return u;
end $$;

create function app.deny(msg text) returns void language plpgsql as $$
begin raise exception '%', msg using errcode = '42501'; end $$;

create function app.next_number(p_org uuid, p_kind text, p_prefix text) returns text language plpgsql security definer set search_path = public, pg_temp as $$
declare v int; y int := extract(year from now())::int;
begin
  insert into doc_counters (organization_id, kind, year, last_value) values (p_org, p_kind, y, 1)
  on conflict (organization_id, kind, year) do update set last_value = doc_counters.last_value + 1
  returning last_value into v;
  return format('%s-%s-%s', p_prefix, y, lpad(v::text, 6, '0'));
end $$;

create function app.notify_approvers(p_project uuid, p_type text, p_title text, p_body text, p_table text, p_id uuid) returns void
language sql security definer set search_path = public, pg_temp as $$
  insert into notifications (user_id, type, title, body, entity_table, entity_id)
  select distinct pm.user_id, p_type, p_title, p_body, p_table, p_id
  from project_members pm join user_roles ur on ur.user_id = pm.user_id and ur.revoked_at is null
  where pm.project_id = p_project and pm.removed_at is null and ur.role in ('project_manager','sales_manager')
$$;

create function app.notify_user(p_user uuid, p_type text, p_title text, p_body text, p_table text, p_id uuid) returns void
language sql security definer set search_path = public, pg_temp as $$
  insert into notifications (user_id, type, title, body, entity_table, entity_id) values (p_user, p_type, p_title, p_body, p_table, p_id)
$$;

-- ---------------------------------------------------------------- prices
create function public.set_lot_price(p_lot uuid, p_price numeric, p_reason text default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); l lots; t timestamptz := clock_timestamp();
begin
  select * into l from lots where id = p_lot and deleted_at is null for update;
  if not found then raise exception 'Lot not found'; end if;
  if not app.has_project_role(l.project_id, array['project_manager']::app_role[]) then
    perform app.deny('Not authorized to change property prices'); end if;
  if p_price is null or p_price < 0 then raise exception 'Price must be zero or positive'; end if;
  if l.status in ('reserved','sold') then raise exception 'Cannot change the price of a % lot', l.status; end if;
  update lot_prices set effective_to = t where lot_id = p_lot and effective_to is null;
  insert into lot_prices (lot_id, project_id, price, effective_from, reason, set_by) values (p_lot, l.project_id, p_price, t, p_reason, u);
  update lots set current_price = p_price where id = p_lot;
end $$;

-- Manual availability changes (available / unavailable / on_hold). Reserved & sold are workflow-only.
create function public.set_lot_availability(p_lot uuid, p_status lot_status, p_reason text default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); l lots;
begin
  select * into l from lots where id = p_lot and deleted_at is null for update;
  if not found then raise exception 'Lot not found'; end if;
  if not app.has_project_role(l.project_id, array['project_manager','sales_manager']::app_role[]) then
    perform app.deny('Not authorized to change lot availability'); end if;
  if p_status not in ('available','unavailable','on_hold') then raise exception 'Status % can only be set through reservation/sale workflows', p_status; end if;
  if l.status not in ('available','unavailable','on_hold') then raise exception 'Lot is % and cannot be changed manually', l.status; end if;
  perform set_config('app.status_reason', coalesce(p_reason,''), true);
  update lots set status = p_status where id = p_lot;
end $$;

-- ---------------------------------------------------------------- reservations
create function public.create_reservation(p_lot uuid, p_buyer uuid, p_fee numeric default 0,
  p_expires_at timestamptz default null, p_notes text default null) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); l lots; b buyers; pr projects; rid uuid; no text;
begin
  select * into l from lots where id = p_lot and deleted_at is null for update;     -- serializes competing reservations
  if not found then raise exception 'Lot not found'; end if;
  if not app.has_project_role(l.project_id, array['salesperson','sales_manager','project_manager']::app_role[]) then
    perform app.deny('Not authorized to create reservations for this project'); end if;
  if not app.can_view_buyer(p_buyer) then perform app.deny('No access to this buyer'); end if;
  select * into b from buyers where id = p_buyer;
  select * into pr from projects where id = l.project_id;
  if b.organization_id <> pr.organization_id then raise exception 'Buyer and project belong to different organizations'; end if;
  if l.status <> 'available' then raise exception 'Lot is not available (status: %)', l.status; end if;
  no := app.next_number(pr.organization_id, 'RSV', 'RSV');
  insert into reservations (organization_id, project_id, lot_id, buyer_id, agent_id, created_by, reservation_no, reservation_fee, expires_at, notes)
  values (pr.organization_id, l.project_id, p_lot, p_buyer, u, u, no, coalesce(p_fee,0), coalesce(p_expires_at, now() + interval '7 days'), p_notes)
  returning id into rid;
  perform set_config('app.status_reason', 'Reservation submitted ' || no, true);
  perform set_config('app.ref_reservation', rid::text, true);
  update lots set status = 'on_hold' where id = p_lot;
  insert into approvals (project_id, reservation_id, requested_by) values (l.project_id, rid, u);
  perform app.notify_approvers(l.project_id, 'reservation_pending', 'Reservation awaiting approval', no || ' for lot ' || l.lot_number, 'reservations', rid);
  return rid;
end $$;

create function public.decide_reservation(p_reservation uuid, p_approve boolean, p_comments text default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); r reservations;
begin
  select * into r from reservations where id = p_reservation for update;
  if not found then raise exception 'Reservation not found'; end if;
  if not app.is_approver(r.project_id) then perform app.deny('Only authorized managers can approve reservations'); end if;
  if r.agent_id = u or r.created_by = u then perform app.deny('You cannot approve your own reservation'); end if;
  if r.status <> 'pending_approval' then raise exception 'Reservation is %, not pending approval', r.status; end if;
  if not p_approve and nullif(trim(p_comments),'') is null then raise exception 'A reason is required to reject'; end if;
  perform set_config('app.ref_reservation', r.id::text, true);
  if p_approve then
    update reservations set status = 'approved', approved_by = u, approved_at = now() where id = r.id;
    perform set_config('app.status_reason', 'Reservation approved ' || r.reservation_no, true);
    update lots set status = 'reserved' where id = r.lot_id;
  else
    update reservations set status = 'rejected', rejection_reason = p_comments where id = r.id;
    perform set_config('app.status_reason', 'Reservation rejected ' || r.reservation_no, true);
    update lots set status = 'available' where id = r.lot_id;
  end if;
  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected'::approval_status end,
         decided_by = u, decided_at = now(), comments = p_comments
   where reservation_id = r.id and status = 'pending';
  perform app.notify_user(r.agent_id, 'reservation_decided', 'Reservation ' || case when p_approve then 'approved' else 'rejected' end, r.reservation_no, 'reservations', r.id);
end $$;

create function public.cancel_reservation(p_reservation uuid, p_reason text) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); r reservations;
begin
  select * into r from reservations where id = p_reservation for update;
  if not found then raise exception 'Reservation not found'; end if;
  if not (r.agent_id = u or app.is_approver(r.project_id)) then perform app.deny('Not authorized to cancel this reservation'); end if;
  if r.status not in ('pending_approval','approved') then raise exception 'Reservation is %, cannot cancel', r.status; end if;
  if nullif(trim(p_reason),'') is null then raise exception 'A cancellation reason is required'; end if;
  if exists (select 1 from sales where reservation_id = r.id and status in ('pending_approval','approved','completed')) then
    raise exception 'Reservation has an active sale; cancel the sale first'; end if;
  update reservations set status = 'cancelled', cancelled_by = u, cancelled_at = now(), cancel_reason = p_reason where id = r.id;
  update approvals set status = 'rejected', decided_by = u, decided_at = now(), comments = 'Cancelled: ' || p_reason
   where reservation_id = r.id and status = 'pending' and requested_by <> u;
  perform set_config('app.status_reason', 'Reservation cancelled ' || r.reservation_no, true);
  perform set_config('app.ref_reservation', r.id::text, true);
  update lots set status = 'available' where id = r.lot_id and status in ('on_hold','reserved');
end $$;

-- Scheduled job (pg_cron / Edge Function with service_role). Not callable by API users.
create function public.expire_reservations() returns int language plpgsql security definer set search_path = public, pg_temp as $$
declare r reservations; n int := 0;
begin
  for r in select * from reservations where status in ('pending_approval','approved') and expires_at < now()
           and not exists (select 1 from sales s where s.reservation_id = reservations.id and s.status in ('pending_approval','approved','completed'))
           for update skip locked loop
    update reservations set status = 'expired' where id = r.id;
    perform set_config('app.status_reason', 'Reservation expired ' || r.reservation_no, true);
    update lots set status = 'available' where id = r.lot_id and status in ('on_hold','reserved');
    n := n + 1;
  end loop;
  return n;
end $$;

-- ---------------------------------------------------------------- sales
create function public.create_sale_from_reservation(p_reservation uuid, p_discount numeric, p_downpayment_pct numeric,
  p_financing financing_type, p_term_months int, p_interest_rate_pct numeric, p_first_due_date date) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); r reservations; l lots; sid uuid; no text;
begin
  select * into r from reservations where id = p_reservation for update;
  if not found then raise exception 'Reservation not found'; end if;
  if not (r.agent_id = u or app.is_approver(r.project_id)) then perform app.deny('Not authorized to create a sale from this reservation'); end if;
  if r.status <> 'approved' then raise exception 'Reservation must be approved first (status: %)', r.status; end if;
  if r.expires_at < now() then raise exception 'Reservation has expired'; end if;
  select * into l from lots where id = r.lot_id for update;
  if l.status <> 'reserved' or l.current_price is null then raise exception 'Lot is not in a sellable state'; end if;
  no := app.next_number(r.organization_id, 'SAL', 'SAL');
  insert into sales (organization_id, project_id, lot_id, buyer_id, reservation_id, agent_id, created_by, sale_no, list_price, discount,
                     financing_type, downpayment_pct, term_months, interest_rate_pct, first_due_date)
  values (r.organization_id, r.project_id, r.lot_id, r.buyer_id, r.id, r.agent_id, u, no, l.current_price, coalesce(p_discount,0),
          p_financing, p_downpayment_pct, coalesce(p_term_months,0), coalesce(p_interest_rate_pct,0), p_first_due_date)
  returning id into sid;
  insert into approvals (project_id, sale_id, requested_by) values (r.project_id, sid, u);
  perform app.notify_approvers(r.project_id, 'sale_pending', 'Sale awaiting approval', no, 'sales', sid);
  return sid;
end $$;

create function app.generate_payment_schedule(p_sale uuid) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare s sales; r reservations; fee numeric; upfront numeric; dp_line numeric; bal numeric; n int := 0; i int; mr numeric; pmt numeric; last_amt numeric;
begin
  select * into s from sales where id = p_sale;
  select * into r from reservations where id = s.reservation_id;
  fee := least(r.reservation_fee, s.net_price);
  upfront := greatest(fee, s.downpayment_amount);
  dp_line := upfront - fee;
  bal := s.net_price - upfront;
  if fee > 0 then n := n + 1;
    insert into payment_schedules (project_id, sale_id, installment_no, item_type, due_date, amount_due) values (s.project_id, s.id, n, 'reservation_fee', r.reserved_at::date, fee); end if;
  if dp_line > 0 then n := n + 1;
    insert into payment_schedules (project_id, sale_id, installment_no, item_type, due_date, amount_due) values (s.project_id, s.id, n, 'downpayment', s.first_due_date, dp_line); end if;
  if bal > 0 then
    if s.term_months < 1 then raise exception 'Term is required when a balance remains'; end if;
    if s.interest_rate_pct = 0 then pmt := round(bal / s.term_months, 2);
    else mr := s.interest_rate_pct / 100 / 12; pmt := round(bal * mr / (1 - power(1 + mr, -s.term_months)), 2); end if;
    for i in 1..s.term_months loop
      n := n + 1;
      last_amt := case when i = s.term_months and s.interest_rate_pct = 0 then bal - pmt * (s.term_months - 1) else pmt end;
      insert into payment_schedules (project_id, sale_id, installment_no, item_type, due_date, amount_due)
      values (s.project_id, s.id, n, 'amortization', (s.first_due_date + make_interval(months => i))::date, last_amt);
    end loop;
  end if;
end $$;

create function public.decide_sale(p_sale uuid, p_approve boolean, p_comments text default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); s sales; rate numeric;
begin
  select * into s from sales where id = p_sale for update;
  if not found then raise exception 'Sale not found'; end if;
  if not app.is_approver(s.project_id) then perform app.deny('Only authorized managers can approve sales'); end if;
  if u in (s.agent_id, s.created_by) then perform app.deny('You cannot approve your own sale'); end if;
  if s.status <> 'pending_approval' then raise exception 'Sale is %, not pending approval', s.status; end if;
  if not p_approve and nullif(trim(p_comments),'') is null then raise exception 'A reason is required to reject'; end if;
  perform set_config('app.ref_sale', s.id::text, true);
  perform set_config('app.ref_reservation', s.reservation_id::text, true);
  if p_approve then
    perform 1 from lots where id = s.lot_id for update;
    update sales set status = 'approved', approved_by = u, approved_at = now() where id = s.id;
    update reservations set status = 'converted' where id = s.reservation_id;
    perform set_config('app.status_reason', 'Sale approved ' || s.sale_no, true);
    update lots set status = 'sold' where id = s.lot_id;
    perform app.generate_payment_schedule(s.id);
    select cr.rate_pct into rate from commission_rules cr
     where cr.project_id = s.project_id and cr.is_active and cr.applies_from <= current_date order by cr.applies_from desc limit 1;
    if rate is not null then
      insert into commissions (project_id, sale_id, agent_id, rate_pct, base_amount) values (s.project_id, s.id, s.agent_id, rate, s.net_price);
    end if;
    perform app.notify_user(s.agent_id, 'sale_decided', 'Sale approved', s.sale_no, 'sales', s.id);
  else
    update sales set status = 'rejected', rejection_reason = p_comments where id = s.id;
    perform app.notify_user(s.agent_id, 'sale_decided', 'Sale rejected', s.sale_no, 'sales', s.id);
  end if;
  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected'::approval_status end,
         decided_by = u, decided_at = now(), comments = p_comments where sale_id = s.id and status = 'pending';
end $$;

-- ---------------------------------------------------------------- payments
-- Keeps schedule.amount_paid/status and sale completion in sync with posted allocations.
create function app.recompute_schedule(p_schedule uuid) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare ps payment_schedules; paid numeric; st schedule_status; open_cnt int;
begin
  select * into ps from payment_schedules where id = p_schedule for update;
  select coalesce(sum(a.amount),0) into paid from payment_allocations a join payments p on p.id = a.payment_id
   where a.schedule_id = p_schedule and p.status = 'posted';
  st := case when ps.status = 'waived' then 'waived'
             when paid >= ps.amount_due then 'paid'
             when ps.due_date < current_date then 'overdue'
             when paid > 0 then 'partial' else 'pending' end;
  update payment_schedules set amount_paid = paid, status = st where id = p_schedule;
  select count(*) into open_cnt from payment_schedules where sale_id = ps.sale_id and status not in ('paid','waived');
  if open_cnt = 0 then
    update sales set status = 'completed', completed_at = now() where id = ps.sale_id and status = 'approved';
  else
    update sales set status = 'approved', completed_at = null where id = ps.sale_id and status = 'completed';
  end if;
end $$;

create function app.on_allocation() returns trigger language plpgsql as $$
begin perform app.recompute_schedule(new.schedule_id); return new; end $$;
create trigger trg_alloc_recompute after insert on public.payment_allocations for each row execute function app.on_allocation();

create function app.on_payment_void() returns trigger language plpgsql as $$
declare sc uuid;
begin
  for sc in select schedule_id from payment_allocations where payment_id = new.id loop perform app.recompute_schedule(sc); end loop;
  return new;
end $$;
create trigger trg_payment_void_recompute after update of status on public.payments for each row when (new.status = 'void') execute function app.on_payment_void();

-- Allocated total may never exceed the payment amount (checked at commit, so multi-row inserts are fine).
create function app.check_allocation_total() returns trigger language plpgsql as $$
declare tot numeric; amt numeric;
begin
  select coalesce(sum(amount),0) into tot from payment_allocations where payment_id = new.payment_id;
  select amount into amt from payments where id = new.payment_id;
  if tot > amt then raise exception 'Allocations (%) exceed payment amount (%)', tot, amt using errcode = '23514'; end if;
  return null;
end $$;
create constraint trigger trg_alloc_total after insert on public.payment_allocations deferrable initially deferred
  for each row execute function app.check_allocation_total();

create function public.record_payment(p_sale uuid, p_amount numeric, p_method payment_method,
  p_reference text default null, p_paid_at timestamptz default null, p_notes text default null) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); s sales; pid uuid; outstanding numeric; left_amt numeric; it payment_schedules; a numeric;
begin
  select * into s from sales where id = p_sale for update;
  if not found then raise exception 'Sale not found'; end if;
  if not app.has_project_role(s.project_id, array['accounting']::app_role[]) then perform app.deny('Not authorized to record payments'); end if;
  if s.status <> 'approved' then raise exception 'Payments can only be recorded against approved sales (status: %)', s.status; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Payment amount must be positive'; end if;
  select coalesce(sum(amount_due - amount_paid),0) into outstanding from payment_schedules where sale_id = p_sale and status not in ('paid','waived');
  if p_amount > outstanding then raise exception 'Payment % exceeds outstanding balance %', p_amount, outstanding; end if;
  insert into payments (organization_id, project_id, sale_id, buyer_id, receipt_no, amount, method, reference_no, paid_at, recorded_by, notes)
  values (s.organization_id, s.project_id, s.id, s.buyer_id, app.next_number(s.organization_id,'OR','OR'), p_amount, p_method, p_reference,
          coalesce(p_paid_at, now()), u, p_notes) returning id into pid;
  left_amt := p_amount;
  for it in select * from payment_schedules where sale_id = p_sale and status not in ('paid','waived') order by installment_no for update loop
    exit when left_amt <= 0;
    a := least(left_amt, it.amount_due - it.amount_paid);
    insert into payment_allocations (payment_id, schedule_id, sale_id, amount) values (pid, it.id, p_sale, a);
    left_amt := left_amt - a;
  end loop;
  return pid;
end $$;

create function public.void_payment(p_payment uuid, p_reason text) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); p payments;
begin
  select * into p from payments where id = p_payment for update;
  if not found then raise exception 'Payment not found'; end if;
  if not app.has_project_role(p.project_id, array['accounting']::app_role[]) then perform app.deny('Not authorized to void payments'); end if;
  if p.status = 'void' then raise exception 'Payment already voided'; end if;
  if nullif(trim(p_reason),'') is null then raise exception 'A void reason is required'; end if;
  update payments set status = 'void', voided_by = u, voided_at = now(), void_reason = p_reason where id = p_payment;
end $$;

-- Mark overdue lines (daily cron / service_role).
create function public.mark_overdue_schedules() returns int language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  update payment_schedules set status = 'overdue' where due_date < current_date and status in ('pending','partial');
  get diagnostics n = row_count; return n;
end $$;

-- ---------------------------------------------------------------- commissions
create function public.approve_commission(p_commission uuid) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); c commissions;
begin
  select * into c from commissions where id = p_commission for update;
  if not found then raise exception 'Commission not found'; end if;
  if not app.is_approver(c.project_id) then perform app.deny('Only authorized managers can approve commissions'); end if;
  if c.agent_id = u then perform app.deny('You cannot approve your own commission'); end if;
  if c.status <> 'pending' then raise exception 'Commission is %, not pending', c.status; end if;
  update commissions set status = 'approved', approved_by = u, approved_at = now() where id = c.id;
  perform app.notify_user(c.agent_id, 'commission_approved', 'Commission approved', null, 'commissions', c.id);
end $$;

create function public.pay_commission(p_commission uuid, p_reference text default null) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); c commissions;
begin
  select * into c from commissions where id = p_commission for update;
  if not found then raise exception 'Commission not found'; end if;
  if not app.has_project_role(c.project_id, array['accounting']::app_role[]) then perform app.deny('Not authorized to pay commissions'); end if;
  if c.status <> 'approved' then raise exception 'Commission must be approved before payment (status: %)', c.status; end if;
  update commissions set status = 'paid', paid_by = u, paid_at = now(), payment_reference = p_reference where id = c.id;
  perform app.notify_user(c.agent_id, 'commission_paid', 'Commission paid', p_reference, 'commissions', c.id);
end $$;

-- ---------------------------------------------------------------- buyer sharing
create function public.grant_buyer_access(p_buyer uuid, p_user uuid, p_can_edit boolean default false,
  p_expires_at timestamptz default null, p_reason text default null) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); b buyers; gid uuid;
begin
  select * into b from buyers where id = p_buyer and deleted_at is null;
  if not found or b.organization_id <> app.org_id() then raise exception 'Buyer not found'; end if;
  if not (b.owner_id = u or app.is_admin()
          or (app.has_any_role(array['sales_manager','project_manager']::app_role[]) and app.can_view_buyer(p_buyer))) then
    perform app.deny('Not authorized to share this buyer'); end if;
  if not exists (select 1 from profiles where id = p_user and organization_id = b.organization_id and is_active and deleted_at is null) then
    raise exception 'Grantee not found in this organization'; end if;
  if p_user = u then raise exception 'Cannot grant access to yourself'; end if;
  update buyer_access_grants set revoked_at = now() where buyer_id = p_buyer and granted_to = p_user and revoked_at is null;
  insert into buyer_access_grants (buyer_id, granted_to, granted_by, can_edit, expires_at, reason)
  values (p_buyer, p_user, u, coalesce(p_can_edit,false), p_expires_at, p_reason) returning id into gid;
  return gid;
end $$;

create function public.revoke_buyer_access(p_grant uuid) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); g buyer_access_grants; b buyers;
begin
  select * into g from buyer_access_grants where id = p_grant for update;
  if not found then raise exception 'Grant not found'; end if;
  select * into b from buyers where id = g.buyer_id;
  if not (b.owner_id = u or g.granted_by = u or app.is_admin()) then perform app.deny('Not authorized to revoke this grant'); end if;
  update buyer_access_grants set revoked_at = now() where id = p_grant and revoked_at is null;
end $$;

create function public.transfer_buyer(p_buyer uuid, p_new_owner uuid) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); b buyers;
begin
  select * into b from buyers where id = p_buyer and deleted_at is null for update;
  if not found or b.organization_id <> app.org_id() then raise exception 'Buyer not found'; end if;
  if not (app.is_admin() or (app.has_any_role(array['sales_manager']::app_role[]) and app.can_view_buyer(p_buyer))) then
    perform app.deny('Only managers can transfer buyer ownership'); end if;
  if not exists (select 1 from profiles where id = p_new_owner and organization_id = b.organization_id and is_active and deleted_at is null) then
    raise exception 'New owner not found in this organization'; end if;
  update buyers set owner_id = p_new_owner where id = p_buyer;
end $$;

-- ---------------------------------------------------------------- soft deletion
-- Soft delete is a function (not a direct UPDATE of deleted_at): PostgreSQL also checks the NEW row against the SELECT
-- policy during UPDATE, and the SELECT policies hide deleted rows, so a plain UPDATE would always be rejected by RLS.
create function public.soft_delete(p_table text, p_id uuid, p_reason text default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); pid uuid; bid uuid; org uuid; up uuid; asg uuid; crt uuid;
begin
  case p_table
  when 'lots' then
    select project_id into pid from lots where id = p_id and deleted_at is null for update;
    if pid is null then raise exception 'Record not found'; end if;
    if not app.has_project_role(pid, array['project_manager']::app_role[]) then perform app.deny('Not authorized to delete lots'); end if;
    if exists (select 1 from lots where id = p_id and status in ('reserved','sold'))
       or exists (select 1 from reservations where lot_id = p_id) or exists (select 1 from sales where lot_id = p_id) then
      raise exception 'Lot has reservation/sales history and cannot be deleted'; end if;
    update lots set deleted_at = now() where id = p_id;
  when 'blocks' then
    select project_id into pid from blocks where id = p_id and deleted_at is null for update;
    if pid is null then raise exception 'Record not found'; end if;
    if not app.has_project_role(pid, array['project_manager']::app_role[]) then perform app.deny('Not authorized to delete blocks'); end if;
    if exists (select 1 from lots where block_id = p_id and deleted_at is null) then raise exception 'Block still contains lots'; end if;
    update blocks set deleted_at = now() where id = p_id;
  when 'phases' then
    select project_id into pid from phases where id = p_id and deleted_at is null for update;
    if pid is null then raise exception 'Record not found'; end if;
    if not app.has_project_role(pid, array['project_manager']::app_role[]) then perform app.deny('Not authorized to delete phases'); end if;
    if exists (select 1 from blocks where phase_id = p_id and deleted_at is null) then raise exception 'Phase still contains blocks'; end if;
    update phases set deleted_at = now() where id = p_id;
  when 'buyers' then
    if not app.can_edit_buyer(p_id) then perform app.deny('Not authorized to delete this buyer'); end if;
    if exists (select 1 from reservations where buyer_id = p_id and status in ('pending_approval','approved'))
       or exists (select 1 from sales where buyer_id = p_id and status in ('pending_approval','approved','completed')) then
      raise exception 'Buyer has active reservations or sales and cannot be deleted'; end if;
    update buyers set deleted_at = now() where id = p_id and deleted_at is null;
  when 'buyer_addresses' then
    select buyer_id into bid from buyer_addresses where id = p_id and deleted_at is null;
    if bid is null then raise exception 'Record not found'; end if;
    if not app.can_edit_buyer(bid) then perform app.deny('Not authorized to delete this address'); end if;
    update buyer_addresses set deleted_at = now() where id = p_id;
  when 'leads' then
    select assigned_to, created_by, project_id into asg, crt, pid from leads where id = p_id and deleted_at is null and organization_id = app.org_id();
    if asg is null then raise exception 'Record not found'; end if;
    if not (u in (asg, crt) or app.is_admin() or (pid is not null and app.is_approver(pid))) then perform app.deny('Not authorized to delete this lead'); end if;
    update leads set deleted_at = now() where id = p_id;
  when 'documents' then
    select organization_id, uploaded_by, project_id into org, up, pid from documents where id = p_id and deleted_at is null;
    if org is null or org <> app.org_id() then raise exception 'Record not found'; end if;
    if not (up = u or app.is_admin() or app.has_any_role(array['documents_officer','sales_manager','project_manager']::app_role[])) then
      perform app.deny('Not authorized to delete this document'); end if;
    update documents set deleted_at = now() where id = p_id;
  else raise exception 'Soft delete is not supported for %', p_table;
  end case;
end $$;

create function public.restore_record(p_table text, p_id uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare u uuid := app.me(); org uuid;
begin
  if not app.is_admin() then perform app.deny('Only administrators can restore deleted records'); end if;
  org := case p_table
    when 'lots'      then (select pr.organization_id from lots x join projects pr on pr.id = x.project_id where x.id = p_id)
    when 'blocks'    then (select pr.organization_id from blocks x join projects pr on pr.id = x.project_id where x.id = p_id)
    when 'phases'    then (select pr.organization_id from phases x join projects pr on pr.id = x.project_id where x.id = p_id)
    when 'buyers'    then (select organization_id from buyers where id = p_id)
    when 'leads'     then (select organization_id from leads where id = p_id)
    when 'documents' then (select organization_id from documents where id = p_id)
    else null end;
  if org is null or org <> app.org_id() then raise exception 'Record not found'; end if;
  execute format('update public.%I set deleted_at = null where id = $1', p_table) using p_id;
end $$;
