-- RGV Property360 :: 002 Organizations, departments, users, roles
create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  code text not null check (code ~ '^[A-Za-z0-9_-]{2,20}$'),
  name text not null check (length(trim(name)) > 0),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index organizations_code_uq on public.organizations (lower(code)) where deleted_at is null;

create table public.departments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id),
  name text not null check (length(trim(name)) > 0),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index departments_name_uq on public.departments (organization_id, lower(name)) where deleted_at is null;

-- One profile per Supabase auth user.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  organization_id uuid not null references public.organizations(id),
  department_id uuid references public.departments(id),
  full_name text not null check (length(trim(full_name)) > 0),
  email text not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  phone text,
  employee_no text,
  is_active boolean not null default true,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index profiles_email_uq on public.profiles (organization_id, lower(email)) where deleted_at is null;
create unique index profiles_empno_uq on public.profiles (organization_id, employee_no) where employee_no is not null and deleted_at is null;
create index profiles_org_idx on public.profiles (organization_id);
create index profiles_dept_idx on public.profiles (department_id);

-- Roles are additive; revoked_at keeps an audit trail instead of deleting.
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  role public.app_role not null,
  granted_by uuid references public.profiles(id),
  revoked_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index user_roles_active_uq on public.user_roles (user_id, role) where revoked_at is null;
create index user_roles_user_idx on public.user_roles (user_id) where revoked_at is null;

comment on table public.organizations is 'Tenant root. All business data hangs off an organization (directly or via project).';
comment on table public.departments   is 'Organizational units (Sales, Accounting, Legal...). Unique name per organization.';
comment on table public.profiles      is 'Application profile 1:1 with auth.users. is_active=false locks the user out of every RLS policy.';
comment on table public.user_roles    is 'Additive global roles. Project scope comes from project_members. Revoke by setting revoked_at.';
